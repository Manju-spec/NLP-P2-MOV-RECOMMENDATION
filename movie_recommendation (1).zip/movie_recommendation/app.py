from flask import Flask, request, render_template
import pickle
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load saved files
tfidf = pickle.load(open("models/tfidf_vectorizer.pkl", "rb"))
tfidf_matrix = pickle.load(open("models/tfidf_matrix.pkl", "rb"))
df = pickle.load(open("models/movies.pkl", "rb"))

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/recommend', methods=['POST'])
def recommend():
    movie = request.form['movie']
    if movie not in df['title'].values:
        return render_template("index.html", error="Movie not found. Try another.")

    idx = df[df['title'] == movie].index[0]
    cosine_sim = cosine_similarity(tfidf_matrix[idx], tfidf_matrix).flatten()
    similar_indices = cosine_sim.argsort()[-6:-1][::-1]
    recommended = df['title'].iloc[similar_indices].values.tolist()

    return render_template("index.html", movie=movie, recommendations=recommended)

if __name__ == "__main__":
    app.run(debug=True)
